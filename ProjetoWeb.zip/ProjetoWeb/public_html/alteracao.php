<?php
session_start();
require("config.php");

    $sql_ativo=sprintf("select * from ativar;");
    $querry=mysqli_query($ligacao,$sql_ativo);
    $reg_ativo=mysqli_fetch_array($querry);

if($reg_ativo['ativo']==1 and $_SESSION['nivel']!=3){
    header('location:/manutencao.php');
}

if(isset($_POST['back1'])){
    
    header('location:admin.php');
}

if(isset($_POST['verif'])){
    
    header('location:lista.php');
}

if(isset($_POST['submeter'])){
    $erros='';
    if(strlen($_POST['nome'])==0){
        $erros.= ' ERRO NO NOME <br>';
    }
    if(strlen($_POST['mail'])==0){
        $erros.= ' ERRO NO EMAIL <br>';
    } else {
           if(!strpos($_POST['mail'], '@')){
               $erros.= ' FALTA O @ NO EMAIL <br>';
           } 
           if(!strpos($_POST['mail'], '.')){
                $erros.= ' FALTA O .(PONTO) NO EMAIL <br>';
            }
    }
    if($_POST['nivel']!=0 and $_POST['nivel']!=3){
        $erros.= ' TEM DE COLOCAR NIVEL 0 OU 3 <br>';
    }
    
    if(isset($_POST['submeter'])){
        if($erros==''){
        $sql_up=sprintf("update begincard set nome='%s', apelido='%s', mail='%s', nivel='%s' where id=%d;",$_POST['nome'],$_POST['apelido'],$_POST['mail'],$_POST['nivel'],$_POST['id']);
        if(mysqli_query($ligacao,$sql_up)){
            $sucesso='DADOS ALTERADOS COM SUCESSO';
            } else{
                    $erros = 'OS DADOS NÃO FORAM ALTERADOS';
             }
        }
    }
}

mysqli_set_charset($ligacao,'UTF8'); // DEFINE O CHARSET DO OUTPUT DE MYSQL

$sql_procura=sprintf("select * from begincard where id=%d;",$_POST['id']);
$res_procura=mysqli_query($ligacao,$sql_procura);
$reg_procura=mysqli_fetch_array($res_procura);
?>     

<h2>EDITAR DADOS</h2>

<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Landing PAGE Html5 Template">
    <meta name="keywords" content="landing,startup,flat">
    <meta name="author" content="Made By GN DESIGNS">

    <title>Begin Car - Vortex layout</title>

    <!-- // PLUGINS (css files) // -->
    <link href="assets/js/plugins/bootsnav_files/skins/color.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/animate.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/bootsnav.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/overwrite.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.theme.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.transitions.css" rel="stylesheet">
    <link href="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/magnific-popup.css" rel="stylesheet">
    <!--// ICONS //-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--// BOOTSTRAP & Main //-->
    <link href="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet">
</head>

<body>

    <!--======================================== 
           Preloader
    ========================================-->
    <div class="page-preloader">
        <div class="spinner">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
        </div>
    </div>
      <!--======================================== 
           Header
    ========================================-->

    <!--//** Navigation**//-->
    <nav class="navbar navbar-default navbar-fixed white no-background bootsnav navbar-scrollspy" data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">

        <div class="container">
            <!-- Start Header Navigation -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                    <i class="fa fa-bars"></i>
                </button>
            </div>
        </div>
            <!-- End Header Navigation -->
<hr>
<form method="post">
    <input type="text" name="nome" placeholder="NOME" value="<?php echo $reg_procura['nome']; ?>" >
    <input type="text" name="apelido" placeholder="APELIDO" value="<?php echo $reg_procura['apelido']; ?>" >
    <input type="text" name="mail" placeholder="EMAIL" value="<?php echo $reg_procura['mail']; ?>">
    <input type="text" name="nivel" placeholder="NIVEL" value="<?php echo $reg_procura['nivel']; ?>">
    <input type="submit" name="submeter" class="btn btn-blue" value="submeter">
    <input type="hidden" name="id" value="<?php echo $reg_procura['id']; ?>">
</form>
        
<?php
        if(isset($_POST['submeter'])){
            if(isset($sucesso)){
?>              <div class='alert alert-success'>
                    <?php echo $sucesso; ?>
                </div>
<?php
        }
        if(isset($_POST['submeter'])){
            if($erros!=''){
?>
                <div class='alert alert-danger'>
                    <?php echo $erros; ?>
                </div>      
<?php            
            }
        }
    }
?>
        
 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/js/plugins/bootsnav_files/js/bootsnav.js"></script>
    <script src="assets/js/plugins/typed.js-master/typed.js-master/dist/typed.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
    <script src="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
    <script src="assets/js/main.js"></script>
    
</body>
          <hr>
        <form class="contact-form" method="post">
                 <button type="submit" name="back1" class="btn btn-blue" style="width: 10%;">Voltar</button>
        </form>
        
</html> 
     