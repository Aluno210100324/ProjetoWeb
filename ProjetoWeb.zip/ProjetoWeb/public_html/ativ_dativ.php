<?php
session_start();
require("config.php");

    $sql_ativo=sprintf("select * from ativar;");
    $querry=mysqli_query($ligacao,$sql_ativo);
    $reg_ativo=mysqli_fetch_array($querry);

if($reg_ativo['ativo']==1 and $_SESSION['nivel']!=3){
    header('location:/manutencao.php');
}

if(isset($_POST['back1'])){
    
    header('location:produtos.php');
}

if($_SESSION['nivel']!=3){
    header('location:login.php');
}

$sql_lista=sprintf("select * from produtos order by nome_prod asc;");
$res_lista=mysqli_query($ligacao,$sql_lista);

if(isset($_POST['dativar'])){
    $sql_up=sprintf("update produtos set ver=1 where id=%d",$_POST['id']);
    mysqli_query($ligacao,$sql_up);
    header('location:ativ_dativ.php');
}
if(isset($_POST['ativar'])){
    $sql_up=sprintf("update produtos set ver=0 where id=%d",$_POST['id']);
    mysqli_query($ligacao,$sql_up);
    header('location:ativ_dativ.php');
}
   
?>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Landing PAGE Html5 Template">
    <meta name="keywords" content="landing,startup,flat">
    <meta name="author" content="Made By GN DESIGNS">

    <title>Begin Car - Vortex layout</title>

    <!-- // PLUGINS (css files) // -->
    <link href="assets/js/plugins/bootsnav_files/skins/color.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/animate.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/bootsnav.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/overwrite.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.theme.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.transitions.css" rel="stylesheet">
    <link href="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/magnific-popup.css" rel="stylesheet">
    <!--// ICONS //-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--// BOOTSTRAP & Main //-->
    <link href="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet">
</head>

<body>

    <!--======================================== 
           Preloader
    ========================================-->
    <div class="page-preloader">
        <div class="spinner">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
        </div>
    </div>
      <!--======================================== 
           Header
    ========================================-->

    <!--//** Navigation**//-->
    <nav  data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">

        <div class="container">
            <!-- Start Header Navigation -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                    <i class="fa fa-bars"></i>
                </button>
            </div>
        </div>
    </nav>
            <!-- End Header Navigation -->

 
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            margin-left: auto;
            margin-right: auto;
        }
         
        td,th {
            border: 1px solid #44c5ee;
            text-align: left;
            padding: 8px;
        }
         
        h1 {
            color: #44c5ee;
        }
    </style>
   
    <?php
        if(isset($_POST['apagar'])){
    ?>
        <form method="post">
            <h3>CONFIRMA QUE QUER APAGAR O REGISTO DE <?php echo $_POST['nome_prod']; ?></h3>
            <input type="submit" name="confirmar" class="btn btn-blue" value="CONFIRMAR" >
            <input type="submit" name="cancelar" class="btn btn-blue" value="CANCELAR" >
            <input type="hidden" name="id" value="<?php echo $_POST['id']; ?>">
            <input type="hidden" name="id" value="<?php echo $_POST['id']; ?>">
        </form>
    <?php
        } else {
    ?>
   
    <center>
        <h2>Aprovação de Produtos</h2>
        <hr>
       
        <b>Procurar:
          <input id="myInput" onkeyup="myFunction()" type="text" placeholder="insira um nome">
        </b>
        <br>
        <br>
        <table id="myTable">
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Descrição</th>
                <th>Preço</th>
                <th>Stock</th>
                <th>Imagem 1</th>
                <th>Imagem 2</th>
                <th>Imagem 3</th>
                <th>APROVAÇÃO</th>
            </tr>
            <tbody>
                <?php
                    while($reg_lista=mysqli_fetch_array($res_lista)){
                ?>
                    <tr>
                        <td align="center"><?php echo $reg_lista['id']; ?></td>
                        <td align="center"><?php echo $reg_lista['nome_prod']; ?></td>
                        <td align="center"><?php echo $reg_lista['descricao']; ?></td>
                        <td align="center"><?php echo $reg_lista['preco']; ?>€</td>
                        <td align="center"><?php echo $reg_lista['stock']; ?></td>
                        <td align="center"><img src="<?php echo $reg_lista['ficheiro']; ?>" width="105px" height="95px" alt=""></td>
                        <td align="center"><img src="<?php echo $reg_lista['ficheiro2']; ?>" width="105px" height="95px" alt=""></td>
                        <td align="center"><img src="<?php echo $reg_lista['ficheiro3']; ?>" width="105px" height="95px" alt=""></td>
                        <td>
                        <?php
                            if($reg_lista['ver']==1){
                        ?>
                                <form method="post">
                                    <button type="submit" name="ativar" class="btn btn-blue" style="width: 100%;">ATIVAR</button>
                                    <input type="hidden" name="id" value="<?php echo $reg_lista['id']; ?>">
                                </form>
                        <?php
                            } else {     
                        ?>
                                <form method="post">
                                    <button type="submit" name="dativar" class="btn btn-blue" style="width: 100%;">DESATIVAR</button>
                                    <input type="hidden" name="id" value="<?php echo $reg_lista['id']; ?>">
                                </form>
                        <?php
                            }
                        ?>
                        </td>
                    </tr>
                <?php
                    }
                        if(isset($_POST['confirmar'])){
                        if(isset($sucesso)){
                ?>          <div class='alert alert-success'>
                                <?php echo $sucesso; ?>
                            </div> <br>
                <?php
                        }
                            if(isset($_POST['confirmar'])){
                            if(isset($erros)){
                ?>
                            <div class='alert alert-danger'>
                                <?php echo $erros; ?>
                            </div>      
                <?php            
                            }
                            }
                        }
                ?>
            </tbody>
        </table>
 
        <script>
            function myFunction() {
              // Declare variables
              var input, filter, table, tr, td, i, txtValue;
              input = document.getElementById("myInput");
              filter = input.value.toUpperCase();
              table = document.getElementById("myTable");
              tr = table.getElementsByTagName("tr");

              // Loop through all table rows, and hide those who don't match the search query
              for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[1];
                if (td) {
                  txtValue = td.textContent || td.innerText;
                  if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                  } else {
                    tr[i].style.display = "none";
                  }
                }
              }
            }
        </script>
    <?php
        }
    ?>
  </center>
        <hr>
        <form class="contact-form" method="post">
                 <button type="submit" name="back1" class="btn btn-blue" style="width: 10%;">Voltar</button>
        </form>
    
 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/js/plugins/bootsnav_files/js/bootsnav.js"></script>
    <script src="assets/js/plugins/typed.js-master/typed.js-master/dist/typed.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
    <script src="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
    <script src="assets/js/main.js"></script>
    
    </body>
</html> 