<?php
session_start();
require('config.php'); 

    $sql_ativo=sprintf("select * from ativar;");
    $querry=mysqli_query($ligacao,$sql_ativo);
    $reg_ativo=mysqli_fetch_array($querry);

if($reg_ativo['ativo']==1 and $_SESSION['nivel']!=3){
    header('location:/manutencao.php');
}

if(isset($_POST['back'])){
    
    header('location:admin.php');
}

if($_SESSION['nivel']!=3){
    header('location:login.php');
}

if(isset($_POST['submeter'])){
    $erros='';
    if(strlen($_POST['nome'])==0){
        $erros.= ' ERRO NO NOME <br>';
    }
    if(strlen($_POST['mail'])==0){
        $erros.= ' ERRO NO EMAIL <br>';
    } else {
           if(!strpos($_POST['mail'], '@')){
               $erros.= ' FALTA O @ NO EMAIL <br>';
           } 
           if(!strpos($_POST['mail'], '.')){
                $erros.= ' FALTA O .(PONTO) NO EMAIL <br>';
            }
    }
    if(strlen($_POST['apelido'])==0){
        $erros.= ' ERRO NO APELIDO <br>';
    }
    /*if(strlen($_POST['pass']) < 8){
        $erros.= ' ERRO NA PASSWORD <br>';
        $erros.= ' DIGITE UMA PASSWORD COM MAIS DE 8 DIGITOS <br>';
    }*/
    
    if($erros==''){
        $sql_con=sprintf("select * from begincard where mail='%s'",$_POST['mail']);
        $res_con=mysqli_query($ligacao,$sql_con);
        $num_con=mysqli_num_rows($res_con);
        
        if($num_con==0){
            $senha=md5($_POST['pass']);
            $sql_inserir=sprintf("insert into begincard (nome,apelido,mail,pass) values ('%s','%s', '%s', '%s');",$_POST['nome'],$_POST['apelido'],$_POST['mail'],$senha);

            if(!mysqli_query($ligacao,$sql_inserir)){
                $erros = 'FALHA NA GRAVAÇÃO DOS DADOS';
            } else{
                $sucesso = 'UTILIZADOR CRIADO COM SUCESSO';
            }
        }else{
                $erros = 'ESTE UTILIZADOR JÁ EXISTE';
        }
     }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Landing PAGE Html5 Template">
    <meta name="keywords" content="landing,startup,flat">
    <meta name="author" content="Made By GN DESIGNS">

    <title>Begin Car - Vortex layout</title>

    <!-- // PLUGINS (css files) // -->
    <link href="assets/js/plugins/bootsnav_files/skins/color.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/animate.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/bootsnav.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/overwrite.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.theme.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.transitions.css" rel="stylesheet">
    <link href="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/magnific-popup.css" rel="stylesheet">
    <!--// ICONS //-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--// BOOTSTRAP & Main //-->
    <link href="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet">
</head>

<style>
    tab { padding-right: 100em; }  
</style>     
    
<body>

    <!--======================================== 
           Preloader
    ========================================-->
    <div class="page-preloader">
        <div class="spinner">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
        </div>
    </div>
    <!--======================================== 
           Header
    ========================================-->

    <!--//** Navigation**//-->
    <nav data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">

        <div class="container">
            <!-- Start Header Navigation -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" >
                    <img src="assets/img/begincar.png" class="logo" alt="logo" style="width: 150px;">
                </a>
            </div>
            <!-- End Header Navigation -->
            
                <div class="col-md-5 col-md-offset-1">
                    <form method="post" class="signup-form">
                        <h2 class="text-center">Criar Utilizador</h2>
                        <hr>
                        <div class="form-group">
                            <input type="text" name="nome" class="form-control" placeholder="Nome" required="required">
                        </div>
                        <div class="form-group">
                            <input type="text" name="apelido" class="form-control" placeholder="Apelido" required="required">
                        </div>
                        <div class="form-group">
                            <input type="email" name="mail" class="form-control" placeholder="Endereço Email" required="required">
                        </div>
                        <div class="form-group">
                            <input type="password" name="pass" class="form-control" placeholder="Password" required="required">
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" name="submeter" class="btn btn-blue btn-block">Enviar</button>
                               <br>
                                <?php
                                        if(isset($_POST['submeter'])){
                                        if($erros==''){
                                ?>          <div class='alert alert-success'>
                                                <?php echo $sucesso; ?>
                                            </div><br>
                                <?php
                                        } else {
                                ?>           <div class='alert alert-danger'>
                                                 <?php echo $erros; ?>
                                             </div>      
                                <?php            
                                        }
                                    }
                                ?>
                        </div>
                    </form>
                </div><br><tab></tab>   
            <hr>
            <form class="contact-form" method="post">
                <p align="left"><button type="submit" name="back" class="btn btn-blue" style="width: 10%;">Voltar</button></p>
            </form>
        </div>

                
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/js/plugins/bootsnav_files/js/bootsnav.js"></script>
    <script src="assets/js/plugins/typed.js-master/typed.js-master/dist/typed.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
    <script src="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>