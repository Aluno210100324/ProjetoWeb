<?php
session_start();
require('config.php');

    $sql_ativo=sprintf("select * from ativar;");
    $querry=mysqli_query($ligacao,$sql_ativo);
    $reg_ativo=mysqli_fetch_array($querry);

if($reg_ativo['ativo']==1 and $_SESSION['nivel']!=3){
    header('location:/manutencao.php');
}

if(!isset($_SESSION['maillog'])){
    
    header('location:index.php');
}
  
if(isset($_POST['login'])){
    
    header('location:logout.php');
}

if(isset($_POST['def'])){
    
    header('location:definicoes.php');
}

if(isset($_POST['loja'])){
    
    header('location:web/index.php');
}

if(isset($erros)){    
    echo '<h1 style="color: red;">'.$erros.'</h1>';
}
if(isset($sucesso)){
    echo '<h1 style="color: green;">'.$sucesso.'</h1>';
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Landing PAGE Html5 Template">
    <meta name="keywords" content="landing,startup,flat">
    <meta name="author" content="Made By GN DESIGNS">

    <title>Begin Car - Vortex layout</title>

    <!-- // PLUGINS (css files) // -->
    <link href="assets/js/plugins/bootsnav_files/skins/color.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/animate.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/bootsnav.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/overwrite.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.theme.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.transitions.css" rel="stylesheet">
    <link href="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/magnific-popup.css" rel="stylesheet">
    <!--// ICONS //-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--// BOOTSTRAP & Main //-->
    <link href="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet">
</head>

<body>

    <!--======================================== 
           Preloader
    ========================================-->
    <div class="page-preloader">
        <div class="spinner">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
        </div>
    </div>
    <!--======================================== 
           Header
    ========================================-->

    <!--//** Navigation**//-->
    <nav class="navbar navbar-default navbar-fixed white no-background bootsnav navbar-scrollspy" data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">

        <div class="container">
            <!-- Start Header Navigation -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" >
                    <img src="assets/img/begincar.png" class="logo" alt="logo" style="width: 90px;">
                </a>
            </div>
            <!-- End Header Navigation -->

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="navbar-menu">
                <ul class="nav navbar-nav navbar-right">
                    <li class="active scroll"><a href="#home">Inicio</a></li>
                    <li class="scroll"><a href="#services">Loja</a></li>
                    <li class="scroll"><a href="#clients">Patrocinadores</a></li>
                    <li class="scroll"><a href="#features">Sobre</a></li>
                    <li class="scroll"><a href="#contact">Contactos</a></li>
                    <li class="button-holder">
                        <button type="button" class="btn btn-blue navbar-btn" data-toggle="modal" data-target="#SignIn">Conta</button>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
    </nav>

    <!--//** Banner**//-->
    <section id="home">
        <div class="container">
            <div class="row">
                <!-- Introduction -->
                <div class="col-md-6 caption">
                    <h1>Bem-vindo</h1>
                    <h2>
                            <span class="animated-text"></span>
                            <span class="typed-cursor"></span>
                        </h2>
                    <a href="#features" class="btn btn-transparent">Sobre nós</a>
                </div>
                <!-- Sign Up -->
                <div class="col-md-5 col-md-offset-1">
                   
                </div>
            </div>
        </div>
    </section>

    <!--======================================== 
           Services
    ========================================-->

        
    <section id="services" class="section-padding">
        <h2>Loja Online</h2>
        <div class="container">
            <div class="row">
                <form class="contact-form" method="post">
                <div class="col-md-3">
                    <div class="icon-box">
                        <img src="assets/img/clients/roda1.jpg" style="width: 50px">
                        <h4>Pneus</h4>
                        <p>Michelin, Continental, GoodYear</p>
                    </div>
                </div>
                </form>
                <div class="col-md-3">
                    <div class="icon-box">
                        <img src="assets/img/clients/filter.jpg" style="width: 50px">
                        <h4>Filtros</h4>
                        <p>TRW, Luk, Mahle, MannFilter</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="icon-box">
                        <img src="assets/img/clients/disco.jpg" style="width: 50px">
                        <h4>Travagem</h4>
                        <p>Hella, Catrol, Ferodo, TRW</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="icon-box">
                        <img src="assets/img/clients/bateria.jpg" style="width: 60px">
                        <h4>Baterias</h4>
                        <p>BMW, Bosch, Varta</p>
                    </div>
                </div>
            </div>
        </div><br>
        <form method="post">
        <div class="form-group text-center">
            <button type="submit" name="loja" class="btn btn-blue">Ir para Loja</button>
        </div>
            </form>
    </section>

    <!--======================================== 
           Clients
    ========================================-->

    <section id="clients" class="section-padding">
        <div class="container">
            <div class="row">
                <h2>Patrocinadores</h2>
                <p>Empresas com quem nós trabalhamos</p>
                <!--// Clients Images //-->
                <div class="clients-images">
                    <div id="owl-clients">
                        <div class="item"><img src="assets/img/clients/logo1.jpg" class="center-block" alt="client" style="width: 200px"></div>
                        <div class="item"><img src="assets/img/clients/logo2.jpg" class="center-block" alt="client" style="width: 200px"></div>
                        <div class="item"><img src="assets/img/clients/logo3.jpg" class="center-block" alt="client" style="width: 150px"></div>
                        <div class="item"><img src="assets/img/clients/logo4.jpg" class="center-block" alt="client" style="width: 150px"></div>
                        <div class="item"><img src="assets/img/clients/logo5.jpg" class="center-block" alt="client" style="width: 150px"></div>
                        <div class="item"><img src="assets/img/clients/logo6.jpg" class="center-block" alt="client" style="width: 200px"></div>
                    </div>
                </div>
                <!--// Clients Testimonials //-->
                <div id="owl-testimonials">
                    <div class="item">
                        <i class="material-icons">mood</i>
                        <p class="quote">A marca TRW é parte da ZF Aftermarket, um líder mundial em produtos de segurança automóvel com a qualidade do equipamento original. Os nossos sistemas TRW de travagem, peças de direção e suspensão são lendários pela qualidade da sua engenharia e pela sua conceção inovadora.</p>
                        <h4>TRW, Company inc.</h4>
                    </div>
                    <div class="item">
                        <i class="material-icons">mood</i>
                        <p class="quote">Todos os anos, mais de 10 milhões veículos novos são equipados com amortecedores SACHS. As nossas embraiagens beneficiam de uma experiência de décadas no desporto automóvel, produzimos peças para o fabricante do equipamento original e para o mercado de pós-venda que proporcionam um desempenho excecional.</p>
                        <h4>Sachs, Company inc.</h4>
                    </div>
                    <div class="item">
                        <i class="material-icons">mood</i>
                        <p class="quote">Por 150 anos, Valvoline está na vanguarda da tecnologia de lubrificantes. Desde a criação do óleo para motor X-18 em 1939, passando pelo óleo de corrida de alto desempenho em 1965 até o óleo MaxLife de quilômetros de altura em 2000, a Valvoline inovou para fornecer aos proprietários produtos de qualidade que maximizam o cuidado do motor.</p>
                        <h4>Valvoline, Company inc.</h4>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--======================================== 
           About Us
    ========================================-->

    <section id="features">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2>Sobre Nós</h2>
                    <p>A Begin Car é uma empresa que comercializa todo o tipo de peças automóveis para todo o tipo de veículos ligeiros.</p>
                    <hr>
                    <div class="feat-media">
                        <!-- Feature -->
                        <div class="media">
                            <div class="media-left">
                                    <i class="material-icons">monetization_on</i>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading">Melhores preços do mercado</h4>
                                <p>Garantimos com toda a certeza que aqui encontrará os preços mais baixos e a melhor qualidade</p>
                            </div>
                        </div>
                        <!-- Feature -->
                        <div class="media">
                            <div class="media-left">
                                    <i class="material-icons">access_time</i>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading">Principal Objetivo</h4>
                                <p>O fornecimento de peças auto aos nossos clientes da mais elevada qualidade a preços justos, a fim de garantir o prazer de ter um automóvel e o seu bom funcionamento. </p>
                            </div>
                        </div>
                        <!-- Feature -->
                        <div class="media">
                            <div class="media-left">
                                    <i class="material-icons">computer</i>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading">Serviço competente</h4>
                                <p>Os nossos funcionários são profissionais e estão sempre prontos para ajudá-lo a escolher as peças auto mais adequadas e a efetuar uma encomenda. Não hesite em contactar-nos!</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Features Img -->
                <div class="col-md-6 col-md-push-1">
                    <img src="assets/img/oficina2.jpg" class="img-responsive" alt="feature" style="width:400px" >
                    <img src="assets/img/oficina.jpg" class="img-responsive" alt="feature" style="width:100%" >
                </div>
            </div>
        </div>
    </section>

    <!--======================================== 
           Contact
    ========================================-->

    <section id="contact" class="section-padding">
        <div class="container">
            <h2>Contacte-nos</h2>
            <p>Em primeiro lugar, é importante garantir-lhe o melhor serviço possível</p>
            <p>Contacte-nos por telefone ou e-mail para obter mais informações da nossa equipa qualificada.</p>
        </div>
        <!-- Contact Info -->
        <div class="container contact-info">
            <div class="row">
                <div class="col-md-4">
                    <div class="icon-box">
                        <i class="material-icons">place</i>
                        <h4>Localização</h4>
                        <p> Rua Doutor Alberto Martins Santos,<br> 2540-087 Bombarral, PT</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="icon-box">
                        <i class="material-icons">phone</i>
                        <h4>Telemovel</h4>
                        <p>261 338 465</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="icon-box">
                        <i class="material-icons">email</i>
                        <h4>Email</h4>
                        <p>info@begincar.com</p>
                    </div>
                </div>
            </div>
        </div>
        <br><br><br><br><br>
        <!-- Contact Form -->
        <div class="contact-forms">
            <div class="container">
                <h2>Caso tenha alguma questão</h2>
                <form class="contact-form" method="post">
                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Nome Completo" required="required">
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-control" placeholder="Email" required="required">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <textarea class="form-control" rows="3" placeholder="Message"></textarea>
                        </div>
                    </div>
                    <button type="submit" name="emails" class="btn btn-blue">Enviar Mensagem</button>
                </form>
            </div>
        </div>
    </section>

    <!--======================================== 
           Footer
    ========================================-->

    <footer>
        <div class="container">
            <div class="row">
                <div class="footer-caption">
                    <img src="assets/img/begincar.png" class="img-responsive center-block" alt="logo" style="width: 100px";>
                    <hr>
                    <h5 class="pull-left">BeginCar, &copy;2019 All rights reserved</h5>
                    <ul class="liste-unstyled pull-right">
                        <li><a href="https://pt-br.facebook.com/"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <!--======================================== 
           Modal
    ========================================-->

    <!-- Modal -->
    <div class="modal fade" id="SignIn" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title text-center" id="myModalLabel">Conta</h4>
                </div>
                <div class="modal-body">
                    <form class="signup-form" method="post">
                        <div class="form-group text-center">
                            <button type="submit" name="def" class="btn btn-blue btn-block">Definições</button><br>
                            <button type="submit" name="login" class="btn btn-blue btn-block">Logout</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/js/plugins/bootsnav_files/js/bootsnav.js"></script>
    <script src="assets/js/plugins/typed.js-master/typed.js-master/dist/typed.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
    <script src="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>