<?php
session_start();
require('config.php'); 

if(isset($_POST['back'])){
    
    header('location:admin.php');
}

if(isset($_POST['login'])){
    $erros=''; 
    if(strlen($_POST['maillog'])==0 or strlen($_POST['passlog'])==0){
        $erros.= ' DADOS INCOMPLETOS <br>';
    }
    if($erros==''){
        $password=md5($_POST['passlog']);
        $sql_con=sprintf("select * from begincard where mail='%s' and pass='%s';",$_POST['maillog'],$password);
        $res_con=mysqli_query($ligacao,$sql_con);
        $num_con=mysqli_num_rows($res_con);
        
        $reg_active=mysqli_fetch_array($res_con);
        
        if($reg_active['active']!=0){
            $erros.= ' UTILIZADOR BLOQUEADO <br>';
        } else {
        if($num_con==1){
            //$reg_con=mysqli_fetch_array($res_con);
            $_SESSION['maillog']=$_POST['maillog'];
            $_SESSION['nivel']=$reg_active['nivel'];
            $_SESSION['nome']=$reg_active['nome'];
            if($_SESSION['nivel']!=3){
                $erros = 'PARA TER ACESSO PRECISA DE SER ADMINISTRADOR';
            }else{
                header('location:man_confirmar.php');
            }     
            
            } else {
                $erros.= ' DADOS DE LOGIN INCORRETOS <br>';
            }
        }   
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Landing PAGE Html5 Template">
    <meta name="keywords" content="landing,startup,flat">
    <meta name="author" content="Made By GN DESIGNS">

    <title>Begin Car - Vortex layout</title>

    <!-- // PLUGINS (css files) // -->
    <link href="assets/js/plugins/bootsnav_files/skins/color.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/animate.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/bootsnav.css" rel="stylesheet">
    <link href="assets/js/plugins/bootsnav_files/css/overwrite.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.theme.css" rel="stylesheet">
    <link href="assets/js/plugins/owl-carousel/owl.transitions.css" rel="stylesheet">
    <link href="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/magnific-popup.css" rel="stylesheet">
    <!--// ICONS //-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--// BOOTSTRAP & Main //-->
    <link href="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet">
</head>

<style>
    tab { padding-right: 100em; }  
</style>     
    
<body>

    <!--======================================== 
           Preloader
    ========================================-->
    <div class="page-preloader">
        <div class="spinner">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
        </div>
    </div>
    <!--======================================== 
           Header
    ========================================-->

    <!--//** Navigation**//-->
    <nav class="navbar navbar-default navbar-fixed white no-background bootsnav navbar-scrollspy" data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">

        <div class="container">
            <!-- Start Header Navigation -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" >
                    <img src="assets/img/begincar.png" class="logo" alt="logo" style="width: 150px;">
                </a>
            </div>
            <!-- End Header Navigation -->
            <div class="col-md-5 col-md-offset-2"><br>
                <h4 class="modal-title text-center" id="myModalLabel">Iniciar sessão</h4><br>
                    <form class="signup-form" method="post">
                        <div class="form-group">
                            <input type="text" name="maillog" class="form-control" placeholder="Email" required="required">
                        </div>
                        <div class="form-group">
                            <input type="password" name="passlog" class="form-control" placeholder="Password" required="required">
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" name="login" class="btn btn-blue btn-block">Entrar</button>
                               <br>
                                <?php
                                        if(isset($_POST['login'])){
                                        if($erros==''){
                                ?>          <div class='alert alert-success'>
                                                <?php echo $sucesso; ?>
                                            </div><br>
                                <?php
                                        } else {
                                ?>           <div class='alert alert-danger'>
                                                 <?php echo $erros; ?>
                                             </div>      
                                <?php            
                                        }
                                    }
                                ?>
                        </div>
                    </form>
                </div><br><tab></tab>   
            <hr>
            <form class="contact-form" method="post">
                <p align="left"><button type="submit" name="back" class="btn btn-blue" style="width: 10%;">Voltar</button></p>
            </form>

                
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/js/plugins/bootsnav_files/js/bootsnav.js"></script>
    <script src="assets/js/plugins/typed.js-master/typed.js-master/dist/typed.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
    <script src="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>