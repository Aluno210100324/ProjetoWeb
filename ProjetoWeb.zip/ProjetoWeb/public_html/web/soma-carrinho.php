<?php
$sql_soma=sprintf("select * from loja_detalhes where mail='%s' and estado=1;",$_SESSION['maillog']);
$res_soma=mysqli_query($ligacao,$sql_soma);

$soma_carrinho=0;

while($reg_soma=mysqli_fetch_array($res_soma)){
    $soma_carrinho+=$reg_soma['quant'];
}

echo $soma_carrinho; 
?>