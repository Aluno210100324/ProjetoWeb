<?php
session_start();
require('config.php');

    $sql_lista=sprintf("select * from produtos where tipo_peca='%s';",$_POST['categ']);
    $res_lista=mysqli_query($ligacao,$sql_lista);

    $sql_ativo=sprintf("select * from ativar;");
    $querry=mysqli_query($ligacao,$sql_ativo);
    $reg_ativo=mysqli_fetch_array($querry);

if($reg_ativo['ativo']==1 and $_SESSION['nivel']!=3){
    header('location:/manutencao.php');
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Begin Car - Produtos</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Classic Style Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<!-- //js -->
<!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
<link href='//fonts.googleapis.com/css?family=Cabin:400,500,600,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,300,700,900' rel='stylesheet' type='text/css'>
</head>
	
<body>
    <input type="hidden" name="categ" value="<?php $_POST['categ'] ?>">
<style>
    tab { padding-right: 8em; }  
    tab1 { padding-right: 1em; } 
    
    .cart_div span {
        font-size: 13px;
        line-height: 6px;
        padding: 1px;
        position: absolute;
        top: 10px;
        color: #fff;
        width: 9px;
        height: 16px;
        text-align: center;
    }
    
    .clean {
        padding: 0;
        border: none;
        background: none;
    }
</style>
<!-- header -->
	<div class="header">
        <div class="header-grid-1">
            <div class="container">
				<div class="header-left animated wow fadeInLeft" data-wow-delay=".5s">
					<ul>
					    <li><i class="glyphicon glyphicon-headphones"></i>Apoio ao cliente 24/7</li>
						<li><i class="glyphicon glyphicon-envelope" ></i><a href="mailto:info@begincar.com">info@begincar.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" ></i>261 338 465</li>
						
					</ul>
				</div>
				<div class="header-right animated wow fadeInRight" data-wow-delay=".5s">
				    <div class="header-right1">
				        <ul><tab></tab>
				            <li><i class="glyphicon glyphicon-user" ></i><a href="login.php">Conta</a></li>
                                <div class="header-right2">
                                    <a href="checkout.php">
                                        <p><img src="images/cart.png" /></p>
                                    </a>
                                        <div class="cart_div"><tab1></tab1>
                                    <a href="checkout.php">        
                                            <span>
                                               <?php
                                                    require('soma-carrinho.php');
                                                ?>
                                            </span>
                                    </a>
                                        </div>
                                </div>
					   </ul>
				    </div>
                 <div class="clearfix"> </div>
				</div>
                 <div class="clearfix"> </div>
			</div>
        </div>
			<div class="container">
			<div class="logo-nav">
				
					<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header nav_2">
						<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						 <div class="navbar-brand logo-nav-left ">
							<h1 class="animated wow pulse" data-wow-delay=".5s"><a href="index.php">Begin<span>Car</span></a></h1>
						</div>


					</div> 
					<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
						<ul class="nav navbar-nav">
							<!-- Mega Menu -->
							<li class="dropdown">
								<a href="" class="dropdown-toggle" data-toggle="dropdown">Peças Auto <b class="caret"></b></a>
								<ul class="dropdown-menu multi">
									<div class="row">
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Sistema de Travagem</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Pastilhas de travão</button></li>
                                                <input type="hidden" value="Pastilhas de travão" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Discos de Travão</button></li>
                                                <input type="hidden" value="Discos de travão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Pinça de travão</button></li>
                                                <input type="hidden" value="Pinça de travão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Jogo de travões</button></li>
                                                <input type="hidden" value="Jogo de travões" name="categ">
                                                </form>
											</ul>
										</div>
                                        <div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Filtros</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Filtro de ar</button></li>
                                                <input type="hidden" value="Filtro de ar" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Filtro de óleo</button></li>
                                                <input type="hidden" value="Filtro de óleo" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Filtro de combustível</button></li>
                                                <input type="hidden" value="Filtro de combustível" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Filtro de habitáculo</button></li>
                                                <input type="hidden" value="Filtro de habitáculo" name="categ">
                                                </form>
											</ul>
										</div>
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Suspensão & direção</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Amortecedores</button></li>
                                                <input type="hidden" value="Amortecedores" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Barra Estabilizadora</button></li>
                                                <input type="hidden" value="Barra Estabilizadora" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Braço de suspensão</button></li>
                                                <input type="hidden" value="Braço de suspensão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Rotula de direção</button></li>
                                                <input type="hidden" value="Rotula de direção" name="categ">
                                                </form>
											</ul><br><br>
										</div>
                                        <div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Embraiagem/Transmissão</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Kit de embraiagem</button></li>
                                                <input type="hidden" value="Kit de embraiagem" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Veio de transmissão</button></li>
                                                <input type="hidden" value="Veio de transmissão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Caixa de velocidades</button></li>
                                                <input type="hidden" value="Caixa de velocidades" name="categ">
                                                </form>
											</ul>
										</div>
                                        <div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Distribuição</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Velas</button></li>
                                                <input type="hidden" value="Velas" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Kit de distribuição</button></li>
                                                <input type="hidden" value="Kit de distribuição" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Correia de distribuição</button></li>
                                                <input type="hidden" value="Correia de distribuição" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Bobina de ignição</button></li>
                                                <input type="hidden" value="Bobina de ignição" name="categ">
                                                </form>
											</ul>
										</div>
                                        <div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<h6>Outras peças</h6>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Elevador do vidro</button></li>
                                                <input type="hidden" value="Elevador do vidro" name="categ">
                                                </form>
												<form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Alternador</button></li>
                                                <input type="hidden" value="Alternador" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Amortecedores da Mala</button></li>
                                                <input type="hidden" value="Braço de suspensão" name="categ">
                                                </form>
                                                <form method="post" action="loja_products.php">
												<li><button class="clean" type="submit">Iluminação / Sinalização</button></li>
                                                <input type="hidden" value="Rotula de direção" name="categ">
                                                </form>
											</ul>
										</div>
                                        
										<div class="clearfix"></div>
									</div>
									
								</ul>
							</li>
                            <li><a>
                                <form method="post" action="loja_products.php">
                                    <button class="clean" type="submit">Pneus</button>
                                    <input type="hidden" value="Pneus" name="categ">
                                </form>
                            </a></li>
							<li><a href="contact.php">Contacto</a></li>
						</ul>
					</div>
					</nav>
				</div>
				
		</div>
	</div>
<!-- //header -->
<!--banner-->
<div class="banner-top">
	<div class="container">
		<h2 class="animated wow fadeInLeft" data-wow-delay=".5s">Produtos</h2>
		<h3 class="animated wow fadeInRight" data-wow-delay=".5s"><a href="index.php">Inicio</a><label>/</label>Produtos<label>/</label><?php echo $_POST['categ'] ?></h3>
		<div class="clearfix"> </div>
	</div>
</div>
	<!--content-->
		<div class="product">
			<div class="container">
						<div class="col-md-3 product-bottom">
			<!--categories-->
			<div class="categories animated wow fadeInUp animated" data-wow-delay=".5s" >
					<h3>Categorias</h3>
					<?php
                        $sql_categ=sprintf("select * from produtos where tipo_peca='%s';",$_POST['categ']);
                        $res_categ=mysqli_query($ligacao,$sql_categ);
                        $reg_categ=mysqli_fetch_array($res_categ);
                
                        $sql_categ2=sprintf("select * from categorias where categ='Sistema de travagem';",$_POST['categ']);
                        $res_categ2=mysqli_query($ligacao,$sql_categ2);
            
                        $sql_categ3=sprintf("select * from categorias where categ='Filtros';",$_POST['categ']);
                        $res_categ3=mysqli_query($ligacao,$sql_categ3);  
            
                        $sql_categ4=sprintf("select * from categorias where categ='Suspensão & direção';",$_POST['categ']);
                        $res_categ4=mysqli_query($ligacao,$sql_categ4); 
            
                        $sql_categ5=sprintf("select * from categorias where categ='Embraiagem/Transmissão';",$_POST['categ']);
                        $res_categ5=mysqli_query($ligacao,$sql_categ5);
            
                        $sql_categ6=sprintf("select * from categorias where categ='Distribuição';",$_POST['categ']);
                        $res_categ6=mysqli_query($ligacao,$sql_categ6);
            
                        $sql_categ7=sprintf("select * from categorias where categ='Outras peças';",$_POST['categ']);
                        $res_categ7=mysqli_query($ligacao,$sql_categ7);
            
                        $sql_categ8=sprintf("select * from categorias where categ='Óleos e fluidos';",$_POST['categ']);
                        $res_categ8=mysqli_query($ligacao,$sql_categ8);
            
                        $sql_categ9=sprintf("select * from categorias where categ='Pneus';",$_POST['categ']);
                        $res_categ9=mysqli_query($ligacao,$sql_categ9);
            
                    ?>
				    <ul class="cate">
				        <li><i class="glyphicon glyphicon-menu-down" ></i><b>Sistema de travagem</b></li>
                             <ul>
                                 <?php 
                                    while($reg_categ2=mysqli_fetch_array($res_categ2)){
                                 ?>
                                 <form method="post" action="loja_products.php">
                                     <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit"><?php echo $reg_categ2['subcateg']; ?></button></li>
                                    <input type="hidden" value="<?php echo $reg_categ2['subcateg']; ?>" name="categ">
                                 </form>
                                 <?php
                                    }
                                 ?>
                             </ul>
                        
                        <li><i class="glyphicon glyphicon-menu-down" ></i><b>Filtros</b></li>
                             <ul>
                                 <?php 
                                    while($reg_categ3=mysqli_fetch_array($res_categ3)){
                                 ?>
                                 <form method="post" action="loja_products.php">
                                     <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit"><?php echo $reg_categ3['subcateg']; ?></button></li>
                                    <input type="hidden" value="<?php echo $reg_categ3['subcateg']; ?>" name="categ">
                                 </form>
                                 <?php
                                    }
                                 ?>
                             </ul>
                        
                        <li><i class="glyphicon glyphicon-menu-down" ></i><b>Suspensão & direção</b></li>
                             <ul>
                                 <?php 
                                    while($reg_categ4=mysqli_fetch_array($res_categ4)){
                                 ?>
                                 <form method="post" action="loja_products.php">
                                     <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit"><?php echo $reg_categ4['subcateg']; ?></button></li>
                                    <input type="hidden" value="<?php echo $reg_categ4['subcateg']; ?>" name="categ">
                                 </form>
                                 <?php
                                    }
                                 ?>
                             </ul>
                
                        <li><i class="glyphicon glyphicon-menu-down" ></i><b>Embraiagem/Transmissão</b></li>
                             <ul>
                                 <?php 
                                    while($reg_categ5=mysqli_fetch_array($res_categ5)){
                                 ?>
                                 <form method="post" action="loja_products.php">
                                     <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit"><?php echo $reg_categ5['subcateg']; ?></button></li>
                                    <input type="hidden" value="<?php echo $reg_categ5['subcateg']; ?>" name="categ">
                                 </form>
                                 <?php
                                    }
                                 ?>
                             </ul>
                
                        <li><i class="glyphicon glyphicon-menu-down" ></i><b>Distribuição</b></li>
                             <ul>
                                 <?php 
                                    while($reg_categ6=mysqli_fetch_array($res_categ6)){
                                 ?>
                                 <form method="post" action="loja_products.php">
                                     <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit"><?php echo $reg_categ6['subcateg']; ?></button></li>
                                    <input type="hidden" value="<?php echo $reg_categ6['subcateg']; ?>" name="categ">
                                 </form>
                                 <?php
                                    }
                                 ?>
                             </ul>

                        <li><i class="glyphicon glyphicon-menu-down" ></i><b>Outras peças</b></li>
                             <ul>
                                 <?php 
                                    while($reg_categ7=mysqli_fetch_array($res_categ7)){
                                 ?>
                                 <form method="post" action="loja_products.php">
                                     <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit"><?php echo $reg_categ7['subcateg']; ?></button></li>
                                    <input type="hidden" value="<?php echo $reg_categ7['subcateg']; ?>" name="categ">
                                 </form>
                                 <?php
                                    }
                                 ?>
                             </ul>
                        
                        <li><i class="glyphicon glyphicon-menu-down" ></i><b>Óleos e fluidos</b></li>
                             <ul>
                                 <?php 
                                    while($reg_categ8=mysqli_fetch_array($res_categ8)){
                                 ?>
                                 <form method="post" action="loja_products.php">
                                     <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit"><?php echo $reg_categ8['subcateg']; ?></button></li>
                                    <input type="hidden" value="<?php echo $reg_categ8['subcateg']; ?>" name="categ">
                                 </form>
                                 <?php
                                    }
                                 ?>
                             </ul>

                        <li><i class="glyphicon glyphicon-menu-down" ></i><b>Pneus</b></li>
                             <ul>
                                 <?php 
                                    while($reg_categ9=mysqli_fetch_array($res_categ9)){
                                 ?>
                                 <form method="post" action="loja_products.php">
                                     <li><i class="glyphicon glyphicon-menu-right" ></i><button class="clean" type="submit"><?php echo $reg_categ9['subcateg']; ?></button></li>
                                    <input type="hidden" value="<?php echo $reg_categ9['subcateg']; ?>" name="categ">
                                 </form>
                                 <?php
                                    }
                                 ?>
                             </ul>
					</ul>
				</div>
		<!--//menu-->
		<!--price-->
				<!--<div class="price animated wow fadeInUp animated" data-wow-delay=".5s" >
					<h3>Price Range</h3>
					<div class="price-head">
					<div class="col-md-6 price-head1">
                                        <div class="price-top1">
                                            <span class="price-top">$</span>
                                            <input type="text"  value="0">
                                        </div>
                                    </div>
									<div class="col-md-6 price-head2">
                                        <div class="price-top1">
                                            <span class="price-top">$</span>
                                            <input type="text"  value="500">
                                        </div>
                                    </div>
									<div class="clearfix"></div>
                                    </div>
                                    </div>-->
			<!--//price-->
			<!--colors-->
			<!--<div class="colors animated wow fadeInLeft animated" data-wow-delay=".5s" >
					<h3>Colors</h3>

                                        <div class="color-top">
                                            <ul>
												<li><a href="#"><i></i></a></li>
												<li><a href="#"><i class="color1"></i></a></li>
												<li><a href="#"><i class="color2"></i></a></li>
												<li><a href="#"><i class="color3"></i></a></li>
												<li><a href="#"><i class="color4"></i></a></li>
												<li><a href="#"><i class="color5"></i></a></li>
												<li><a href="#"><i class="color6"></i></a></li>
												<li><a href="#"><i class="color7"></i></a></li>
											</ul>
                                        </div>
                                    </div>-->
									
                                 
			<!--//colors-->
			<!--<div class="sellers animated wow fadeInUp" data-wow-delay=".5s">
					
								<h3 class="best">BEST SELLERS</h3>
					<div class="product-head">
					<div class="product-go">
						<div class=" fashion-grid">
									<a href="single.php"><img class="img-responsive " src="images/pcc.jpg" alt=""></a>
									
								</div>
							<div class=" fashion-grid1">
								<h6 class="best2"><a href="single.php">Lorem ipsum </a></h6>
								<span class=" price-in1"> <del>$50.00</del>$40.00</span>
								<p>The standard chunk of Lorem Ipsum used</p>
							</div>
								
							<div class="clearfix"> </div>
							</div>
							<div class="product-go">
						<div class=" fashion-grid">
									<a href="single.php"><img class="img-responsive " src="images/pcc1.jpg" alt=""></a>
									
								</div>
							<div class=" fashion-grid1">
								<h6 class="best2"><a href="single.php">Lorem ipsum </a></h6>
								<span class=" price-in1"> <del>$50.00</del>$40.00</span>
								<p>The standard chunk of Lorem Ipsum used</p>
							</div>
							<div class="clearfix"> </div>
							</div>
							
							</div>
				</div>-->
				<!---->
 	</div>
                <div class="col-md-9 animated wow fadeInRight" data-wow-delay=".5s"> 
                <div class="mens-toolbar">
                	<div class="clearfix"></div>		
                    </div>
                
			<div class="mid-popular">
                                    <?php
                                        while($reg_lista=mysqli_fetch_array($res_lista)){
                                            if($reg_lista['ver']==0){
                                    ?>
				<div class="col-sm-4 item-grid item-gr  simpleCart_shelfItem">
							<div class="grid-pro">
								<div  class=" grid-product " >
                                    
									<figure>		
											<div class="grid-img">
												<img  src="<?php echo $reg_lista['ficheiro']; ?>" class="img-resp" alt="">
											</div>					
									</figure>	
								</div>
								<div class="women">
									<h6><?php echo $reg_lista['nome_prod'] ?></h6>
									<p ><em class="item_price"><?php echo number_format($reg_lista['preco'],2); ?>€</em></p>
                                    <a href="single.php?id=<?php echo $reg_lista['id'].'&categ='.$_POST['categ']; ?>" data-text="Detalhes" class="but-hover1 ">Detalhes</a>
								</div>
							</div>
						</div>
                                    <?php
                                            }
                                        }
                                    ?>
				</div>
            </div>

		
			<div class="clearfix"></div>
			</div>			
		</div>
				<!--//products-->
    
	<div class="clearfix"></div>
	
<!-- footer -->
	<div class="footer">
		<div class="container">
		<div class="footer-top">
		<div class="clearfix"> </div>
		</div>
			<div class="footer-grids">
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".5s">
					<h3>Sobre Nós</h3>
					<p>A Begin Car é uma empresa que comercializa todo o tipo de peças automóveis para todo o tipo de veículos ligeiros.<span>Com o melhor preço, qualidade e serviço do mercado.</span></p>
				</div>
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".6s">
					<h3>Os nossos contactos</h3>
					<ul>
						<li><i class="glyphicon glyphicon-map-marker" ></i>Rua Doutor Alberto Martins Santos, <span>2540-087 Bombarral, PT</span></li>
						<li class="foot-mid"><i class="glyphicon glyphicon-envelope" ></i><a href="mailto:info@begincar.com">info@begincar.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" ></i>261 338 465</li>
					</ul>
				</div>
				<div class="col-md-4 footer-grid animated wow fadeInLeft" data-wow-delay=".7s">
				<h3>Deseja receber novidades? </h3>
				<form method=post>
					<input type="text" placeholder="Email"  required="required">
					<input type="submit" value="Enviar">
				</form>
				</div>
                <div class="col-md-2 footer-top2">
		              <a href="contact.php">Contacte-nos</a>
		         </div>
			
				<div class="clearfix"> </div>
			</div>
			
			<div class="copy-right animated wow fadeInUp" data-wow-delay=".5s">
                <p>BeginCar, &copy 2019 All rights reserved </p>
			</div>
		</div>
	</div>
<!-- //footer -->
</body>
</html>